/*
 * RED5 Open Source Media Server - https://github.com/Red5/ Copyright 2006-2023 by respective authors (see below). All rights reserved. Licensed under the Apache License, Version
 * 2.0 (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 Unless
 * required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions and limitations under the License.
 */

package org.red5.server.stream;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

import org.apache.mina.core.buffer.IoBuffer;
import org.red5.codec.IAudioStreamCodec;
import org.red5.codec.IStreamCodecInfo;
import org.red5.codec.IVideoStreamCodec;
import org.red5.codec.IVideoStreamCodec.FrameData;
import org.red5.codec.StreamCodecInfo;
import org.red5.codec.VideoFrameType;
import org.red5.io.amf.Output;
import org.red5.io.utils.ObjectMap;
import org.red5.server.api.scheduling.IScheduledJob;
import org.red5.server.api.scheduling.ISchedulingService;
import org.red5.server.api.scope.IBroadcastScope;
import org.red5.server.api.scope.IScope;
import org.red5.server.api.stream.IBroadcastStream;
import org.red5.server.api.stream.IPlayItem;
import org.red5.server.api.stream.IPlaylistSubscriberStream;
import org.red5.server.api.stream.ISubscriberStream;
import org.red5.server.api.stream.OperationNotSupportedException;
import org.red5.server.api.stream.StreamState;
import org.red5.server.api.stream.support.DynamicPlayItem;
import org.red5.server.messaging.AbstractMessage;
import org.red5.server.messaging.IConsumer;
import org.red5.server.messaging.IFilter;
import org.red5.server.messaging.IMessage;
import org.red5.server.messaging.IMessageComponent;
import org.red5.server.messaging.IMessageInput;
import org.red5.server.messaging.IMessageOutput;
import org.red5.server.messaging.IPassive;
import org.red5.server.messaging.IPipe;
import org.red5.server.messaging.IPipeConnectionListener;
import org.red5.server.messaging.IProvider;
import org.red5.server.messaging.IPushableConsumer;
import org.red5.server.messaging.InMemoryPushPushPipe;
import org.red5.server.messaging.OOBControlMessage;
import org.red5.server.messaging.PipeConnectionEvent;
import org.red5.server.net.rtmp.event.Aggregate;
import org.red5.server.net.rtmp.event.AudioData;
import org.red5.server.net.rtmp.event.IRTMPEvent;
import org.red5.server.net.rtmp.event.Notify;
import org.red5.server.net.rtmp.event.Ping;
import org.red5.server.net.rtmp.event.Ping.PingType;
import org.red5.server.net.rtmp.event.VideoData;
import org.red5.server.net.rtmp.message.Constants;
import org.red5.server.net.rtmp.message.Header;
import org.red5.server.net.rtmp.status.Status;
import org.red5.server.net.rtmp.status.StatusCodes;
import org.red5.server.stream.message.RTMPMessage;
import org.red5.server.stream.message.ResetMessage;
import org.red5.server.stream.message.StatusMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A play engine for playing a IPlayItem.
 *
 * @author The Red5 Project
 * @author Steven Gong
 * @author Paul Gregoire (mondain@gmail.com)
 * @author Dan Rossi
 * @author Tiago Daniel Jacobs (tiago@imdt.com.br)
 * @author Vladimir Hmelyoff (vlhm@splitmedialabs.com)
 * @author Andy Shaules
 */
public final class PlayEngine implements IFilter, IPushableConsumer, IPipeConnectionListener {

    private static final Logger log = LoggerFactory.getLogger(PlayEngine.class);

    private static boolean isDebug = log.isDebugEnabled();

    private static boolean isTrace = log.isTraceEnabled();

    private final AtomicReference<IMessageInput> msgInReference = new AtomicReference<>();

    private final AtomicReference<IMessageOutput> msgOutReference = new AtomicReference<>();

    private final ISubscriberStream subscriberStream;

    private ISchedulingService schedulingService;

    private IConsumerService consumerService;

    private IProviderService providerService;

    private Number streamId;

    /**
     * Receive video?
     */
    private boolean receiveVideo = true;

    /**
     * Receive audio?
     */
    private boolean receiveAudio = true;

    private boolean pullMode;

    private String waitLiveJob;

    /**
     * timestamp of first sent packet
     */
    private AtomicInteger streamStartTS = new AtomicInteger(-1);

    /**
     * For late subscribers, stores the publisher's current timestamp when playLive() is called.
     * Used to generate relative timestamps for the subscriber.
     */
    private int publisherTimestampOffset = 0;

    /**
     * For late subscribers, track audio and video base timestamps separately to ensure
     * both streams start at ts=2 for proper A/V sync.
     */
    private volatile int audioBaseTs = -1;

    private volatile int videoBaseTs = -1;

    private AtomicReference<IPlayItem> currentItem = new AtomicReference<>();

    private RTMPMessage pendingMessage;

    /**
     * Interval in ms to check for buffer underruns in VOD streams.
     */
    private int bufferCheckInterval = 0;

    /**
     * Number of pending messages at which a NetStream.Play.InsufficientBW message is generated for VOD streams.
     */
    private int underrunTrigger = 10;

    /**
     * Threshold for number of pending video frames
     */
    private int maxPendingVideoFrames = 10;

    /**
     * If we have more than 1 pending video frames, but less than maxPendingVideoFrames, continue sending until there are this many
     * sequential frames with more than 1 pending
     */
    private int maxSequentialPendingVideoFrames = 10;

    /**
     * the number of sequential video frames with > 0 pending frames
     */
    private int numSequentialPendingVideoFrames = 0;

    /**
     * State machine for video frame dropping in live streams
     */
    private IFrameDropper videoFrameDropper = new VideoFrameDropper();

    /**
     * Flag indicating we're waiting for the first keyframe from the publisher.
     * This allows us to switch to SEND_ALL mode once a keyframe is available.
     */
    private volatile boolean waitingForKeyframe = false;

    private int timestampOffset = 0;

    /**
     * Timestamp of the last message sent to the client.
     */
    private int lastMessageTs = -1;

    /**
     * Number of bytes sent.
     */
    private AtomicLong bytesSent = new AtomicLong(0);

    /**
     * Start time of stream playback. It's not a time when the stream is being played but the time when the stream should be played if it's
     * played from the very beginning. Eg. A stream is played at timestamp 5s on 1:00:05. The playbackStart is 1:00:00.
     */
    private volatile long playbackStart;

    /**
     * Flag denoting whether or not the push and pull job is scheduled. The job makes sure messages are sent to the client.
     */
    private volatile String pullAndPush;

    /**
     * Flag denoting whether or not the job that closes stream after buffer runs out is scheduled.
     */
    private volatile String deferredStop;

    /**
     * Monitor guarding completion of a given push/pull run. Used to wait for job cancellation to finish.
     */
    private final AtomicBoolean pushPullRunning = new AtomicBoolean(false);

    /**
     * Offset in milliseconds where the stream started.
     */
    private int streamOffset;

    /**
     * Timestamp when buffer should be checked for underruns next.
     */
    private long nextCheckBufferUnderrun;

    /**
     * Send blank audio packet next?
     */
    private boolean sendBlankAudio;

    /**
     * Decision: 0 for Live, 1 for File, 2 for Wait, 3 for N/A
     */
    private int playDecision = 3;

    /**
     * Index of the buffered interframe to send instead of current frame
     */
    private int bufferedInterframeIdx = -1;

    /**
     * List of pending operations
     */
    private ConcurrentLinkedQueue<Runnable> pendingOperations = new ConcurrentLinkedQueue<>();

    // Keep count of dropped packets so we can log every so often.
    private long droppedPacketsCount;

    private long droppedPacketsCountLastLogTimestamp = TimeUnit.NANOSECONDS.toMillis(System.nanoTime());

    private long droppedPacketsCountLogInterval = 60 * 1000L;

    private boolean configsDone;

    /**
     * Constructs a new PlayEngine.
     */
    private PlayEngine(Builder builder) {
        subscriberStream = builder.subscriberStream;
        schedulingService = builder.schedulingService;
        consumerService = builder.consumerService;
        providerService = builder.providerService;
        // get the stream id
        streamId = subscriberStream.getStreamId();
    }

    /**
     * Builder pattern
     */
    public final static class Builder {
        //Required for play engine
        private ISubscriberStream subscriberStream;

        //Required for play engine
        private ISchedulingService schedulingService;

        //Required for play engine
        private IConsumerService consumerService;

        //Required for play engine
        private IProviderService providerService;

        public Builder(ISubscriberStream subscriberStream, ISchedulingService schedulingService, IConsumerService consumerService, IProviderService providerService) {
            this.subscriberStream = subscriberStream;
            this.schedulingService = schedulingService;
            this.consumerService = consumerService;
            this.providerService = providerService;
        }

        public PlayEngine build() {
            return new PlayEngine(this);
        }

    }

    /**
     * <p>Setter for the field <code>bufferCheckInterval</code>.</p>
     *
     * @param bufferCheckInterval a int
     */
    public void setBufferCheckInterval(int bufferCheckInterval) {
        this.bufferCheckInterval = bufferCheckInterval;
    }

    /**
     * <p>Setter for the field <code>underrunTrigger</code>.</p>
     *
     * @param underrunTrigger a int
     */
    public void setUnderrunTrigger(int underrunTrigger) {
        this.underrunTrigger = underrunTrigger;
    }

    void setMessageOut(IMessageOutput msgOut) {
        this.msgOutReference.set(msgOut);
    }

    /**
     * Start stream
     */
    public void start() {
        if (isDebug) {
            log.debug("start - subscriber stream state: {}", (subscriberStream != null ? subscriberStream.getState() : null));
        }
        switch (subscriberStream.getState()) {
            case UNINIT:
                // allow start if uninitialized and change state to stopped
                subscriberStream.setState(StreamState.STOPPED);
                IMessageOutput out = consumerService.getConsumerOutput(subscriberStream);
                if (msgOutReference.compareAndSet(null, out)) {
                    out.subscribe(this, null);
                } else if (isDebug) {
                    log.debug("Message output was already set for stream: {}", subscriberStream);
                }
                break;
            default:
                throw new IllegalStateException(String.format("Cannot start in current state: %s", subscriberStream.getState()));
        }
    }

    /**
     * Play stream
     *
     * @param item
     *            Playlist item
     * @throws org.red5.server.stream.StreamNotFoundException
     *             Stream not found
     * @throws java.lang.IllegalStateException
     *             Stream is in stopped state
     * @throws java.io.IOException
     *             Stream had io exception
     */
    public void play(IPlayItem item) throws StreamNotFoundException, IllegalStateException, IOException {
        play(item, true);
    }

    /**
     * Play stream
     *
     * See: https://www.adobe.com/devnet/adobe-media-server/articles/dynstream_actionscript.html
     *
     * @param item
     *            Playlist item
     * @param withReset
     *            Send reset status before playing.
     * @throws org.red5.server.stream.StreamNotFoundException
     *             Stream not found
     * @throws java.lang.IllegalStateException
     *             Stream is in stopped state
     * @throws java.io.IOException
     *             Stream had IO exception
     */
    public void play(IPlayItem item, boolean withReset) throws StreamNotFoundException, IllegalStateException, IOException {
        IMessageInput in = null;
        // cannot play if state is not stopped
        switch (subscriberStream.getState()) {
            case STOPPED:
                in = msgInReference.get();
                if (in != null) {
                    in.unsubscribe(this);
                    msgInReference.set(null);
                }
                break;
            default:
                throw new IllegalStateException("Cannot play from non-stopped state");
        }
        // Play type determination
        // https://help.adobe.com/en_US/FlashPlatform/reference/actionscript/3/flash/net/NetStream.html#play()
        // The start time, in seconds. Allowed values are -2, -1, 0, or a positive number.
        // The default value is -2, which looks for a live stream, then a recorded stream,
        // and if it finds neither, opens a live stream.
        // If -1, plays only a live stream.
        // If 0 or a positive number, plays a recorded stream, beginning start seconds in.
        //
        // -2: live then recorded, -1: live, >=0: recorded
        int type = (int) (item.getStart() / 1000);
        log.debug("Type {}", type);
        // see if it's a published stream
        IScope thisScope = subscriberStream.getScope();
        final String itemName = item.getName();
        //check for input and type
        IProviderService.INPUT_TYPE sourceType = providerService.lookupProviderInput(thisScope, itemName, type);
        boolean sendNotifications = true;
        // decision: 0 for Live, 1 for File, 2 for Wait, 3 for N/A
        switch (type) {
            case -2:
                if (sourceType == IProviderService.INPUT_TYPE.LIVE) {
                    playDecision = 0;
                } else if (sourceType == IProviderService.INPUT_TYPE.VOD) {
                    playDecision = 1;
                } else if (sourceType == IProviderService.INPUT_TYPE.LIVE_WAIT) {
                    playDecision = 2;
                }
                break;
            case -1:
                if (sourceType == IProviderService.INPUT_TYPE.LIVE) {
                    playDecision = 0;
                } else if (sourceType == IProviderService.INPUT_TYPE.LIVE_WAIT) {
                    playDecision = 2;
                }
                break;
            case 0://Gstreamer rtmp2src compatibility.
                if (sourceType == IProviderService.INPUT_TYPE.LIVE) {
                    playDecision = 0;
                } else if (sourceType == IProviderService.INPUT_TYPE.VOD) {
                    playDecision = 1;
                }
                break;
            default:
                if (sourceType == IProviderService.INPUT_TYPE.VOD) {
                    playDecision = 1;
                }
                break;
        }
        IMessage msg = null;
        currentItem.set(item);
        long itemLength = item.getLength();
        if (isDebug) {
            log.debug("Play decision is {} (0=Live, 1=File, 2=Wait, 3=N/A) item length: {}", playDecision, itemLength);
        }
        switch (playDecision) {
            case 0:
                // get source input without create
                in = providerService.getLiveProviderInput(thisScope, itemName, false);
                if (msgInReference.compareAndSet(null, in)) {
                    // drop all frames up to the next keyframe
                    videoFrameDropper.reset(IFrameDropper.SEND_KEYFRAMES_CHECK);
                    waitingForKeyframe = true;
                    log.debug("playItem: set waitingForKeyframe=true, SEND_KEYFRAMES_CHECK mode");
                    if (in instanceof IBroadcastScope) {
                        IBroadcastStream stream = (IBroadcastStream) ((IBroadcastScope) in).getClientBroadcastStream();
                        log.debug("playItem: stream={}, codecInfo={}", stream, stream != null ? stream.getCodecInfo() : "N/A");
                        if (stream != null && stream.getCodecInfo() != null) {
                            IVideoStreamCodec videoCodec = stream.getCodecInfo().getVideoCodec();
                            log.debug("playItem: videoCodec={}, hasKeyframe={}, numInterframes={}", videoCodec, videoCodec != null ? videoCodec.getKeyframe() != null : "N/A", videoCodec != null ? videoCodec.getNumInterframes() : "N/A");
                            if (videoCodec != null) {
                                if (withReset) {
                                    sendReset();
                                    sendResetStatus(item);
                                    sendStartStatus(item);
                                }
                                sendNotifications = false;
                                if (videoCodec.getNumInterframes() > 0 || videoCodec.getKeyframe() != null) {
                                    log.debug("playItem: Keyframe available, switching to SEND_ALL mode");
                                    bufferedInterframeIdx = 0;
                                    videoFrameDropper.reset(IFrameDropper.SEND_ALL);
                                    waitingForKeyframe = false;
                                }
                            }
                        }
                    }
                    // subscribe to stream (ClientBroadcastStream.onPipeConnectionEvent)
                    in.subscribe(this, null);
                    // execute the processes to get Live playback setup
                    playLive();
                } else {
                    sendStreamNotFoundStatus(item);
                    throw new StreamNotFoundException(itemName);
                }
                break;
            case 2:
                // get source input with create
                in = providerService.getLiveProviderInput(thisScope, itemName, true);
                if (msgInReference.compareAndSet(null, in)) {
                    if (type == -1 && itemLength >= 0) {
                        if (isDebug) {
                            log.debug("Creating wait job for {}", itemLength);
                        }
                        // Wait given timeout for stream to be published
                        waitLiveJob = schedulingService.addScheduledOnceJob(itemLength, new IScheduledJob() {
                            public void execute(ISchedulingService service) {
                                connectToProvider(itemName);
                                waitLiveJob = null;
                                subscriberStream.onChange(StreamState.END);
                            }
                        });
                    } else if (type == -2) {
                        if (isDebug) {
                            log.debug("Creating wait job");
                        }
                        // Wait x seconds for the stream to be published
                        waitLiveJob = schedulingService.addScheduledOnceJob(15000, new IScheduledJob() {
                            public void execute(ISchedulingService service) {
                                connectToProvider(itemName);
                                waitLiveJob = null;
                            }
                        });
                    } else {
                        connectToProvider(itemName);
                    }
                } else if (isDebug) {
                    log.debug("Message input already set for {}", itemName);
                }
                break;
            case 1:
                in = providerService.getVODProviderInput(thisScope, itemName);
                if (msgInReference.compareAndSet(null, in)) {
                    if (in.subscribe(this, null)) {
                        // execute the processes to get VOD playback setup
                        msg = playVOD(withReset, itemLength);
                    } else {
                        log.warn("Input source subscribe failed");
                        throw new IOException(String.format("Subscribe to %s failed", itemName));
                    }
                } else {
                    sendStreamNotFoundStatus(item);
                    throw new StreamNotFoundException(itemName);
                }
                break;
            default:
                sendStreamNotFoundStatus(item);
                throw new StreamNotFoundException(itemName);
        }
        // continue with common play processes (live and vod)
        if (sendNotifications) {
            if (withReset) {
                sendReset();
                sendResetStatus(item);
            }
            sendStartStatus(item);
            if (!withReset) {
                sendSwitchStatus();
            }
            // if its dynamic playback send the complete status
            if (item instanceof DynamicPlayItem) {
                sendTransitionStatus();
            }
        }
        if (msg != null) {
            sendMessage((RTMPMessage) msg);
        }
        subscriberStream.onChange(StreamState.PLAYING, item, !pullMode);
        if (withReset) {
            log.debug("Resetting times");
            long currentTime = System.currentTimeMillis();
            playbackStart = currentTime - streamOffset;
            nextCheckBufferUnderrun = currentTime + bufferCheckInterval;
            if (item.getLength() != 0) {
                ensurePullAndPushRunning();
            }
        }
    }

    /**
     * Performs the processes needed for live streams. The following items are sent if they exist:
     * <ul>
     * <li>Metadata</li>
     * <li>Decoder configurations (ie. AVC codec)</li>
     * <li>Most recent keyframe</li>
     * </ul>
     *
     * @throws IOException
     */
    private final void playLive() throws IOException {
        // change state
        subscriberStream.setState(StreamState.PLAYING);
        // Mark this as a late subscriber by setting streamStartTS to 0
        // This will be detected in sendMessage() to generate proper relative timestamps
        streamStartTS.set(0);
        // Reset A/V base timestamps for late subscriber tracking
        audioBaseTs = -1;
        videoBaseTs = -1;
        publisherTimestampOffset = 0;
        log.debug("playLive: Initialized streamStartTS to 0, reset A/V base timestamps");
        IMessageInput in = msgInReference.get();
        IMessageOutput out = msgOutReference.get();
        if (in != null && out != null) {
            // get the stream so that we can grab any metadata and decoder configs
            IBroadcastStream stream = (IBroadcastStream) ((IBroadcastScope) in).getClientBroadcastStream();
            // prevent an NPE when a play list is created and then immediately flushed
            int ts = 0;
            if (stream != null) {
                Notify metaData = stream.getMetaData();
                //check for metadata to send
                if (metaData != null) {
                    ts = metaData.getTimestamp();
                    log.debug("Metadata is available");
                    RTMPMessage metaMsg = RTMPMessage.build(metaData, metaData.getTimestamp());
                    sendMessage(metaMsg);
                } else {
                    log.debug("No metadata available");
                }
                IStreamCodecInfo codecInfo = stream.getCodecInfo();
                log.debug("Codec info: {} stream: {}", codecInfo, stream);
                if (codecInfo instanceof StreamCodecInfo) {
                    StreamCodecInfo info = (StreamCodecInfo) codecInfo;
                    IVideoStreamCodec videoCodec = info.getVideoCodec();
                    IAudioStreamCodec audioCodec = info.getAudioCodec();
                    log.debug("Video codec: {} hasKeyframe: {}", videoCodec, videoCodec != null ? videoCodec.getKeyframe() != null : "N/A");
                    log.debug("Audio codec: {}", audioCodec);
                    // Send decoder configurations first (both at ts=0) to maintain DTS order
                    // 1. Video decoder configuration
                    if (videoCodec != null) {
                        IoBuffer config = videoCodec.getDecoderConfiguration();
                        if (config != null) {
                            log.debug("Decoder configuration is available for {}", videoCodec.getName());
                            VideoData conf = new VideoData(config, true);
                            log.debug("Pushing video decoder configuration");
                            sendMessage(RTMPMessage.build(conf, ts));
                        } else {
                            log.warn("No decoder configuration available for {}", videoCodec.getName());
                        }
                    } else {
                        log.debug("No video decoder configuration available");
                    }
                    // 2. Audio decoder configuration (must come before keyframe to maintain DTS order)
                    if (audioCodec != null) {
                        IoBuffer config = audioCodec.getDecoderConfiguration();
                        if (config != null) {
                            log.debug("Decoder configuration is available for {}", audioCodec.getName());
                            AudioData conf = new AudioData(config.asReadOnlyBuffer());
                            log.debug("Pushing audio decoder configuration");
                            sendMessage(RTMPMessage.build(conf, ts));
                        }
                    } else {
                        log.debug("No audio decoder configuration available");
                    }
                    // 3. Video keyframe (at ts=1, after all ts=0 configs)
                    if (videoCodec != null) {
                        FrameData[] keyFrames = videoCodec.getKeyframes();
                        log.debug("Keyframes count: {}", keyFrames != null ? keyFrames.length : "null");
                        if (keyFrames != null) {
                            for (FrameData keyframe : keyFrames) {
                                log.debug("Keyframe is available");
                                VideoData video = new VideoData(keyframe.getFrame(), true);
                                log.debug("Pushing keyframe");
                                // Use timestamp 1 for keyframe to distinguish from decoder config at 0
                                sendMessage(RTMPMessage.build(video, 1));
                            }
                        }
                        // If no keyframes were sent but we have one in the codec, send it
                        if ((keyFrames == null || keyFrames.length == 0) && videoCodec.getKeyframe() != null) {
                            log.warn("No keyframes array but getKeyframe() is available, sending it");
                            VideoData video = new VideoData(videoCodec.getKeyframe(), true);
                            // Use timestamp 1 for keyframe to distinguish from decoder config at 0
                            sendMessage(RTMPMessage.build(video, 1));
                        }
                    }
                }
            }
        } else {
            throw new IOException(String.format("A message pipe is null - in: %b out: %b", (msgInReference == null), (msgOutReference == null)));
        }
        configsDone = true;
    }

    /**
     * Performs the processes needed for VOD / pre-recorded streams.
     *
     * @param withReset
     *            whether or not to perform reset on the stream
     * @param itemLength
     *            length of the item to be played
     * @return message for the consumer
     * @throws IOException
     */
    private final IMessage playVOD(boolean withReset, long itemLength) throws IOException {
        IMessage msg = null;
        // change state
        subscriberStream.setState(StreamState.PLAYING);
        if (withReset) {
            releasePendingMessage();
        }
        sendVODInitCM(currentItem.get());
        // Don't use pullAndPush to detect IOExceptions prior to sending NetStream.Play.Start
        int start = (int) currentItem.get().getStart();
        if (start > 0) {
            streamOffset = sendVODSeekCM(start);
            // We seeked to the nearest keyframe so use real timestamp now
            if (streamOffset == -1) {
                streamOffset = start;
            }
        }
        IMessageInput in = msgInReference.get();
        msg = in.pullMessage();
        if (msg instanceof RTMPMessage) {
            // Only send first video frame
            IRTMPEvent body = ((RTMPMessage) msg).getBody();
            if (itemLength == 0) {
                while (body != null && !(body instanceof VideoData)) {
                    msg = in.pullMessage();
                    if (msg != null && msg instanceof RTMPMessage) {
                        body = ((RTMPMessage) msg).getBody();
                    } else {
                        break;
                    }
                }
            }
            if (body != null) {
                // Adjust timestamp when playing lists
                body.setTimestamp(body.getTimestamp() + timestampOffset);
            }
        }
        return msg;
    }

    /**
     * Connects to the data provider.
     *
     * @param itemName
     *            name of the item to play
     */
    private final void connectToProvider(String itemName) {
        log.debug("Attempting connection to {}", itemName);
        IMessageInput in = msgInReference.get();
        if (in == null) {
            in = providerService.getLiveProviderInput(subscriberStream.getScope(), itemName, true);
            msgInReference.set(in);
        }
        if (in != null) {
            log.debug("Provider: {}", msgInReference.get());
            if (in.subscribe(this, null)) {
                log.debug("Subscribed to {} provider", itemName);
                // execute the processes to get Live playback setup
                try {
                    playLive();
                } catch (IOException e) {
                    log.warn("Could not play live stream: {}", itemName, e);
                }
            } else {
                log.warn("Subscribe to {} provider failed", itemName);
            }
        } else {
            log.warn("Provider was not found for {}", itemName);
            StreamService.sendNetStreamStatus(subscriberStream.getConnection(), StatusCodes.NS_PLAY_STREAMNOTFOUND, "Stream was not found", itemName, Status.ERROR, streamId);
        }
    }

    /**
     * Pause at position
     *
     * @param position
     *            Position in file
     * @throws java.lang.IllegalStateException
     *             If stream is stopped
     */
    public void pause(int position) throws IllegalStateException {
        // allow pause if playing or stopped
        switch (subscriberStream.getState()) {
            case PLAYING:
            case STOPPED:
                subscriberStream.setState(StreamState.PAUSED);
                clearWaitJobs();
                sendPauseStatus(currentItem.get());
                sendClearPing();
                subscriberStream.onChange(StreamState.PAUSED, currentItem.get(), position);
                break;
            default:
                throw new IllegalStateException("Cannot pause in current state");
        }
    }

    /**
     * Resume playback
     *
     * @param position
     *            Resumes playback
     * @throws java.lang.IllegalStateException
     *             If stream is stopped
     */
    public void resume(int position) throws IllegalStateException {
        // allow resume from pause
        switch (subscriberStream.getState()) {
            case PAUSED:
                subscriberStream.setState(StreamState.PLAYING);
                sendReset();
                sendResumeStatus(currentItem.get());
                if (pullMode) {
                    sendVODSeekCM(position);
                    subscriberStream.onChange(StreamState.RESUMED, currentItem.get(), position);
                    playbackStart = System.currentTimeMillis() - position;
                    long length = currentItem.get().getLength();
                    if (length >= 0 && (position - streamOffset) >= length) {
                        // Resume after end of stream
                        stop();
                    } else {
                        ensurePullAndPushRunning();
                    }
                } else {
                    subscriberStream.onChange(StreamState.RESUMED, currentItem.get(), position);
                    videoFrameDropper.reset(VideoFrameDropper.SEND_KEYFRAMES_CHECK);
                }
                break;
            default:
                throw new IllegalStateException("Cannot resume from non-paused state");
        }
    }

    /**
     * Seek to a given position
     *
     * @param position
     *            Position
     * @throws java.lang.IllegalStateException
     *             If stream is in stopped state
     * @throws org.red5.server.api.stream.OperationNotSupportedException
     *             If this object doesn't support the operation.
     */
    public void seek(int position) throws IllegalStateException, OperationNotSupportedException {
        // add this pending seek operation to the list
        pendingOperations.add(new SeekRunnable(position));
        cancelDeferredStop();
        ensurePullAndPushRunning();
    }

    /**
     * Stop playback
     *
     * @throws java.lang.IllegalStateException
     *             If stream is in stopped state
     */
    public void stop() throws IllegalStateException {
        if (isDebug) {
            log.debug("stop - subscriber stream state: {}", (subscriberStream != null ? subscriberStream.getState() : null));
        }
        // allow stop if playing or paused
        switch (subscriberStream.getState()) {
            case PLAYING:
            case PAUSED:
                subscriberStream.setState(StreamState.STOPPED);
                IMessageInput in = msgInReference.get();
                if (in != null && !pullMode) {
                    in.unsubscribe(this);
                    msgInReference.set(null);
                }
                subscriberStream.onChange(StreamState.STOPPED, currentItem.get());
                clearWaitJobs();
                cancelDeferredStop();
                if (subscriberStream instanceof IPlaylistSubscriberStream) {
                    IPlaylistSubscriberStream pss = (IPlaylistSubscriberStream) subscriberStream;
                    if (!pss.hasMoreItems()) {
                        releasePendingMessage();
                        sendCompleteStatus();
                        bytesSent.set(0);
                        sendStopStatus(currentItem.get());
                        sendClearPing();
                    } else {
                        if (lastMessageTs > 0) {
                            // remember last timestamp so we can generate correct headers in playlists.
                            timestampOffset = lastMessageTs;
                        }
                        pss.nextItem();
                    }
                }
                break;
            case CLOSED:
                clearWaitJobs();
                cancelDeferredStop();
                break;
            case STOPPED:
                log.trace("Already in stopped state");
                break;
            default:
                throw new IllegalStateException(String.format("Cannot stop in current state: %s", subscriberStream.getState()));
        }
    }

    /**
     * Close stream
     */
    public void close() {
        if (isDebug) {
            log.debug("close");
        }
        if (!subscriberStream.getState().equals(StreamState.CLOSED)) {
            IMessageInput in = msgInReference.get();
            if (in != null) {
                in.unsubscribe(this);
                msgInReference.set(null);
            }
            subscriberStream.setState(StreamState.CLOSED);
            clearWaitJobs();
            releasePendingMessage();
            lastMessageTs = 0;
            // XXX is clear ping required?
            //sendClearPing();
            InMemoryPushPushPipe out = (InMemoryPushPushPipe) msgOutReference.get();
            if (out != null) {
                List<IConsumer> consumers = out.getConsumers();
                // assume a list of 1 in most cases
                if (isDebug) {
                    log.debug("Message out consumers: {}", consumers.size());
                }
                if (!consumers.isEmpty()) {
                    for (IConsumer consumer : consumers) {
                        out.unsubscribe(consumer);
                    }
                }
                msgOutReference.set(null);
            }
        } else {
            log.debug("Stream is already in closed state");
        }
    }

    /**
     * Check if it's okay to send the client more data. This takes the configured bandwidth as well as the requested client buffer into
     * account.
     *
     * @param message
     * @return true if it is ok to send more, false otherwise
     */
    private boolean okayToSendMessage(IRTMPEvent message) {
        if (message instanceof IStreamData) {
            final long now = System.currentTimeMillis();
            // check client buffer size
            if (isClientBufferFull(now)) {
                return false;
            }
            // get pending message count
            long pending = pendingMessages();
            if (bufferCheckInterval > 0 && now >= nextCheckBufferUnderrun) {
                if (pending > underrunTrigger) {
                    // client is playing behind speed, notify him
                    sendInsufficientBandwidthStatus(currentItem.get());
                }
                nextCheckBufferUnderrun = now + bufferCheckInterval;
            }
            // check for under run
            if (pending > underrunTrigger) {
                // too many messages already queued on the connection
                return false;
            }
            return true;
        } else {
            String itemName = "Undefined";
            // if current item exists get the name to help debug this issue
            if (currentItem.get() != null) {
                itemName = currentItem.get().getName();
            }
            Object[] errorItems = new Object[] { message.getClass(), message.getDataType(), itemName };
            throw new RuntimeException(String.format("Expected IStreamData but got %s (type %s) for %s", errorItems));
        }
    }

    /**
     * Estimate client buffer fill.
     *
     * @param now
     *            The current timestamp being used.
     * @return True if it appears that the client buffer is full, otherwise false.
     */
    private boolean isClientBufferFull(final long now) {
        // check client buffer length when we've already sent some messages
        if (lastMessageTs > 0) {
            // duration the stream is playing / playback duration
            final long delta = now - playbackStart;
            // buffer size as requested by the client
            final long buffer = subscriberStream.getClientBufferDuration();
            // expected amount of data present in client buffer
            final long buffered = lastMessageTs - delta;
            log.trace("isClientBufferFull: timestamp {} delta {} buffered {} buffer duration {}", new Object[] { lastMessageTs, delta, buffered, buffer });
            // fix for SN-122, this sends double the size of the client buffer
            if (buffer > 0 && buffered > (buffer * 2)) {
                // client is likely to have enough data in the buffer
                return true;
            }
        }
        return false;
    }

    private boolean isClientBufferEmpty() {
        // check client buffer length when we've already sent some messages
        if (lastMessageTs >= 0) {
            // duration the stream is playing / playback duration
            final long delta = System.currentTimeMillis() - playbackStart;
            // expected amount of data present in client buffer
            final long buffered = lastMessageTs - delta;
            log.trace("isClientBufferEmpty: timestamp {} delta {} buffered {}", new Object[] { lastMessageTs, delta, buffered });
            if (buffered < 0) {
                return true;
            }
        }
        return false;
    }

    /**
     * Make sure the pull and push processing is running.
     */
    private void ensurePullAndPushRunning() {
        log.trace("State should be PLAYING to running this task: {}", subscriberStream.getState());
        if (pullMode && pullAndPush == null && subscriberStream.getState() == StreamState.PLAYING) {
            // client buffer is at least 100ms
            pullAndPush = subscriberStream.scheduleWithFixedDelay(new PullAndPushRunnable(), 10);
        }
    }

    /**
     * Clear all scheduled waiting jobs
     */
    private void clearWaitJobs() {
        log.debug("Clear wait jobs");
        if (pullAndPush != null) {
            subscriberStream.cancelJob(pullAndPush);
            releasePendingMessage();
            pullAndPush = null;
        }
        if (waitLiveJob != null) {
            schedulingService.removeScheduledJob(waitLiveJob);
            waitLiveJob = null;
        }
    }

    /**
     * Sends a status message.
     *
     * @param status
     */
    private void doPushMessage(Status status) {
        StatusMessage message = new StatusMessage();
        message.setBody(status);
        doPushMessage(message);
    }

    /**
     * Send message to output stream and handle exceptions.
     *
     * @param message
     *            The message to send.
     */
    private void doPushMessage(AbstractMessage message) {
        if (isTrace) {
            String msgType = message.getMessageType();
            log.trace("doPushMessage: {}", msgType);
        }
        IMessageOutput out = msgOutReference.get();
        if (out != null) {
            try {
                out.pushMessage(message);
                if (message instanceof RTMPMessage) {
                    IRTMPEvent body = ((RTMPMessage) message).getBody();
                    // update the last message sent's timestamp
                    lastMessageTs = body.getTimestamp();
                    IoBuffer streamData = null;
                    if (body instanceof IStreamData && (streamData = ((IStreamData<?>) body).getData()) != null) {
                        bytesSent.addAndGet(streamData.limit());
                    }
                }
            } catch (IOException err) {
                log.warn("Error while pushing message", err);
            }
        } else {
            log.warn("Push message failed due to null output pipe");
        }
    }

    /**
     * Send an RTMP message
     *
     * @param messageIn
     *            incoming RTMP message
     */
    private void sendMessage(RTMPMessage messageIn) {
        IRTMPEvent eventIn = messageIn.getBody();
        IRTMPEvent event;
        switch (eventIn.getDataType()) {
            case Constants.TYPE_AGGREGATE:
                event = new Aggregate(((Aggregate) eventIn).getData());
                break;
            case Constants.TYPE_AUDIO_DATA:
                event = new AudioData(((AudioData) eventIn).getData());
                break;
            case Constants.TYPE_VIDEO_DATA:
                event = new VideoData(((VideoData) eventIn).getData());
                break;
            default:
                event = new Notify(((Notify) eventIn).getData());
                break;
        }
        // get the incoming event time
        int eventTime = eventIn.getTimestamp();
        // get the incoming event source type and set on the outgoing event
        byte incomingSourceType = eventIn.getSourceType();
        event.setSourceType(incomingSourceType);
        // instance the outgoing message
        RTMPMessage messageOut = RTMPMessage.build(event, eventTime);
        if (isTrace || incomingSourceType != Constants.SOURCE_TYPE_LIVE) {
            log.warn("Source type issue - in: {} out: {} event type: {}", new Object[] { incomingSourceType, messageOut.getBody().getSourceType(), eventIn.getClass().getSimpleName() });
            long delta = System.currentTimeMillis() - playbackStart;
            log.trace("sendMessage: streamStartTS {}, length {}, streamOffset {}, timestamp {} last timestamp {} delta {} buffered {}", new Object[] { streamStartTS.get(), currentItem.get().getLength(), streamOffset, eventTime, lastMessageTs, delta, lastMessageTs - delta });
        }
        if (playDecision == 1) { // 1 == vod/file
            if (eventTime > 0 && streamStartTS.compareAndSet(-1, eventTime)) {
                log.debug("sendMessage: set streamStartTS");
                messageOut.getBody().setTimestamp(0);
            }
            long length = currentItem.get().getLength();
            if (length >= 0) {
                int duration = eventTime - streamStartTS.get();
                if (isTrace) {
                    log.trace("sendMessage duration={} length={}", duration, length);
                }
                if (duration - streamOffset >= length) {
                    // sent enough data to client
                    stop();
                    return;
                }
            }
        } else {
            // don't reset streamStartTS to 0 for live streams
            // streamStartTS may be 0 (initialized by playLive) or -1 (not yet initialized)
            if (eventTime > 0) {
                int currentStartTs = streamStartTS.get();
                // Only set streamStartTS if it's -1 (not initialized by playLive)
                // If playLive already set it to 0, keep it at 0 to prevent timestamp adjustment
                // for late subscribers (decoder config at 0, keyframe at 1, live frames at their original timestamps)
                if (currentStartTs == -1 && streamStartTS.compareAndSet(-1, eventTime)) {
                    log.debug("sendMessage: set streamStartTS from -1 to {}", eventTime);
                }
            }
            // relative timestamp adjustment for live streams
            int startTs = streamStartTS.get();
            // For late subscribers (streamStartTS was set to 0 by playLive):
            // Track audio and video base timestamps separately so both start at ts=2
            if (startTs == 0 && eventTime > 1) {
                // This is a late subscriber receiving first live frames
                boolean isVideo = eventIn instanceof VideoData;
                boolean isAudio = eventIn instanceof AudioData;

                if (isVideo && videoBaseTs == -1) {
                    // First video frame for late subscriber - capture base and output ts=2
                    videoBaseTs = eventTime;
                    log.debug("sendMessage: Late subscriber first VIDEO, setting videoBaseTs={}", eventTime);
                    messageOut.getBody().setTimestamp(2);
                    // Also update streamStartTS for general tracking
                    streamStartTS.compareAndSet(0, eventTime);
                    publisherTimestampOffset = eventTime;
                } else if (isAudio && audioBaseTs == -1) {
                    // First audio frame for late subscriber - capture base and output ts=2
                    audioBaseTs = eventTime;
                    log.debug("sendMessage: Late subscriber first AUDIO, setting audioBaseTs={}", eventTime);
                    messageOut.getBody().setTimestamp(2);
                    // Update streamStartTS if not already set
                    if (streamStartTS.compareAndSet(0, eventTime)) {
                        publisherTimestampOffset = eventTime;
                    }
                } else if (isVideo && videoBaseTs > 0) {
                    // Subsequent video frames - adjust using video base
                    eventTime = eventTime - videoBaseTs + 2;
                    messageOut.getBody().setTimestamp(eventTime);
                } else if (isAudio && audioBaseTs > 0) {
                    // Subsequent audio frames - adjust using audio base
                    eventTime = eventTime - audioBaseTs + 2;
                    messageOut.getBody().setTimestamp(eventTime);
                }
            } else if (startTs > 1) {
                // Late subscriber with streamStartTS already captured
                boolean isVideo = eventIn instanceof VideoData;
                boolean isAudio = eventIn instanceof AudioData;

                if (isVideo) {
                    if (videoBaseTs == -1) {
                        // First video frame after streamStartTS was set by audio
                        videoBaseTs = eventTime;
                        log.debug("sendMessage: Late subscriber first VIDEO (after audio), setting videoBaseTs={}", eventTime);
                        eventTime = 2;
                    } else if (videoBaseTs > 0) {
                        eventTime = eventTime - videoBaseTs + 2;
                    } else if (publisherTimestampOffset > 0) {
                        eventTime = eventTime - publisherTimestampOffset + 2;
                    } else {
                        eventTime -= startTs;
                    }
                } else if (isAudio) {
                    if (audioBaseTs == -1) {
                        // First audio frame after streamStartTS was set by video
                        audioBaseTs = eventTime;
                        log.debug("sendMessage: Late subscriber first AUDIO (after video), setting audioBaseTs={}", eventTime);
                        eventTime = 2;
                    } else if (audioBaseTs > 0) {
                        eventTime = eventTime - audioBaseTs + 2;
                    } else if (publisherTimestampOffset > 0) {
                        eventTime = eventTime - publisherTimestampOffset + 2;
                    } else {
                        eventTime -= startTs;
                    }
                } else {
                    // Other data types (metadata, etc.)
                    if (publisherTimestampOffset > 0) {
                        eventTime = eventTime - publisherTimestampOffset + 2;
                    } else {
                        eventTime -= startTs;
                    }
                }
                messageOut.getBody().setTimestamp(eventTime);
                if (isTrace) {
                    log.trace("sendMessage (updated): streamStartTS={}, length={}, streamOffset={}, timestamp={}", new Object[] { startTs, currentItem.get().getLength(), streamOffset, eventTime });
                }
            }
            // For startTs <= 1 (decoder config at 0, keyframe at 1), no adjustment
        }
        // Log final adjusted timestamps for A/V sync debugging
        if (log.isDebugEnabled()) {
            String type = eventIn instanceof VideoData ? "VIDEO" : (eventIn instanceof AudioData ? "AUDIO" : "OTHER");
            log.debug("sendMessage final: type={} originalTs={} adjustedTs={} streamStartTS={}", type, eventIn.getTimestamp(), messageOut.getBody().getTimestamp(), streamStartTS.get());
        }
        doPushMessage(messageOut);
    }

    /**
     * Send clear ping. Lets client know that stream has no more data to send.
     */
    private void sendClearPing() {
        Ping eof = new Ping();
        eof.setEventType(PingType.STREAM_PLAYBUFFER_CLEAR);
        eof.setValue2(streamId);
        // eos
        RTMPMessage eofMsg = RTMPMessage.build(eof);
        doPushMessage(eofMsg);
    }

    /**
     * Send reset message
     */
    private void sendReset() {
        if (pullMode) {
            Ping recorded = new Ping();
            recorded.setEventType(PingType.RECORDED_STREAM);
            recorded.setValue2(streamId);
            // recorded
            RTMPMessage recordedMsg = RTMPMessage.build(recorded);
            doPushMessage(recordedMsg);
        }
        Ping begin = new Ping();
        begin.setEventType(PingType.STREAM_BEGIN);
        begin.setValue2(streamId);
        // begin
        RTMPMessage beginMsg = RTMPMessage.build(begin);
        doPushMessage(beginMsg);
        // reset
        ResetMessage reset = new ResetMessage();
        doPushMessage(reset);
    }

    /**
     * Send reset status for item
     *
     * @param item
     *            Playlist item
     */
    private void sendResetStatus(IPlayItem item) {
        Status reset = new Status(StatusCodes.NS_PLAY_RESET);
        reset.setClientid(streamId);
        reset.setDetails(item.getName());
        reset.setDesciption(String.format("Playing and resetting %s.", item.getName()));

        doPushMessage(reset);
    }

    /**
     * Send playback start status notification
     *
     * @param item
     *            Playlist item
     */
    private void sendStartStatus(IPlayItem item) {
        Status start = new Status(StatusCodes.NS_PLAY_START);
        start.setClientid(streamId);
        start.setDetails(item.getName());
        start.setDesciption(String.format("Started playing %s.", item.getName()));

        doPushMessage(start);
    }

    /**
     * Send playback stoppage status notification
     *
     * @param item
     *            Playlist item
     */
    private void sendStopStatus(IPlayItem item) {
        Status stop = new Status(StatusCodes.NS_PLAY_STOP);
        stop.setClientid(streamId);
        stop.setDesciption(String.format("Stopped playing %s.", item.getName()));
        stop.setDetails(item.getName());

        doPushMessage(stop);
    }

    /**
     * Sends an onPlayStatus message.
     *
     * http://help.adobe.com/en_US/FlashPlatform/reference/actionscript/3/flash/events/NetDataEvent.html
     *
     * @param code
     * @param duration
     * @param bytes
     */
    private void sendOnPlayStatus(String code, int duration, long bytes) {
        if (isDebug) {
            log.debug("Sending onPlayStatus - code: {} duration: {} bytes: {}", code, duration, bytes);
        }
        // create the buffer
        IoBuffer buf = IoBuffer.allocate(102);
        buf.setAutoExpand(true);
        Output out = new Output(buf);
        out.writeString("onPlayStatus");
        ObjectMap<Object, Object> args = new ObjectMap<>();
        args.put("code", code);
        args.put("level", Status.STATUS);
        args.put("duration", duration);
        args.put("bytes", bytes);
        String name = currentItem.get().getName();
        if (StatusCodes.NS_PLAY_TRANSITION_COMPLETE.equals(code)) {
            args.put("clientId", streamId);
            args.put("details", name);
            args.put("description", String.format("Transitioned to %s", name));
            args.put("isFastPlay", false);
        }
        out.writeObject(args);
        buf.flip();
        Notify event = new Notify(buf, "onPlayStatus");
        if (lastMessageTs > 0) {
            event.setTimestamp(lastMessageTs);
        } else {
            event.setTimestamp(0);
        }
        RTMPMessage msg = RTMPMessage.build(event);
        doPushMessage(msg);
    }

    /**
     * Send playlist switch status notification
     */
    private void sendSwitchStatus() {
        // TODO: find correct duration to send
        sendOnPlayStatus(StatusCodes.NS_PLAY_SWITCH, 1, bytesSent.get());
    }

    /**
     * Send transition status notification
     */
    private void sendTransitionStatus() {
        sendOnPlayStatus(StatusCodes.NS_PLAY_TRANSITION_COMPLETE, 0, bytesSent.get());
    }

    /**
     * Send playlist complete status notification
     *
     */
    private void sendCompleteStatus() {
        // may be the correct duration
        int duration = (lastMessageTs > 0) ? Math.max(0, lastMessageTs - streamStartTS.get()) : 0;
        if (isDebug) {
            log.debug("sendCompleteStatus - duration: {} bytes sent: {}", duration, bytesSent.get());
        }
        sendOnPlayStatus(StatusCodes.NS_PLAY_COMPLETE, duration, bytesSent.get());
    }

    /**
     * Send seek status notification
     *
     * @param item
     *            Playlist item
     * @param position
     *            Seek position
     */
    private void sendSeekStatus(IPlayItem item, int position) {
        Status seek = new Status(StatusCodes.NS_SEEK_NOTIFY);
        seek.setClientid(streamId);
        seek.setDetails(item.getName());
        seek.setDesciption(String.format("Seeking %d (stream ID: %d).", position, streamId));

        doPushMessage(seek);
    }

    /**
     * Send pause status notification
     *
     * @param item
     *            Playlist item
     */
    private void sendPauseStatus(IPlayItem item) {
        Status pause = new Status(StatusCodes.NS_PAUSE_NOTIFY);
        pause.setClientid(streamId);
        pause.setDetails(item.getName());

        doPushMessage(pause);
    }

    /**
     * Send resume status notification
     *
     * @param item
     *            Playlist item
     */
    private void sendResumeStatus(IPlayItem item) {
        Status resume = new Status(StatusCodes.NS_UNPAUSE_NOTIFY);
        resume.setClientid(streamId);
        resume.setDetails(item.getName());

        doPushMessage(resume);
    }

    /**
     * Send published status notification
     *
     * @param item
     *            Playlist item
     */
    private void sendPublishedStatus(IPlayItem item) {
        Status published = new Status(StatusCodes.NS_PLAY_PUBLISHNOTIFY);
        published.setClientid(streamId);
        published.setDetails(item.getName());

        doPushMessage(published);
    }

    /**
     * Send unpublished status notification
     *
     * @param item
     *            Playlist item
     */
    private void sendUnpublishedStatus(IPlayItem item) {
        Status unpublished = new Status(StatusCodes.NS_PLAY_UNPUBLISHNOTIFY);
        unpublished.setClientid(streamId);
        unpublished.setDetails(item.getName());

        doPushMessage(unpublished);
    }

    /**
     * Stream not found status notification
     *
     * @param item
     *            Playlist item
     */
    private void sendStreamNotFoundStatus(IPlayItem item) {
        Status notFound = new Status(StatusCodes.NS_PLAY_STREAMNOTFOUND);
        notFound.setClientid(streamId);
        notFound.setLevel(Status.ERROR);
        notFound.setDetails(item.getName());

        doPushMessage(notFound);
    }

    /**
     * Insufficient bandwidth notification
     *
     * @param item
     *            Playlist item
     */
    private void sendInsufficientBandwidthStatus(IPlayItem item) {
        Status insufficientBW = new Status(StatusCodes.NS_PLAY_INSUFFICIENT_BW);
        insufficientBW.setClientid(streamId);
        insufficientBW.setLevel(Status.WARNING);
        insufficientBW.setDetails(item.getName());
        insufficientBW.setDesciption("Data is playing behind the normal speed");

        doPushMessage(insufficientBW);
    }

    /**
     * Send VOD init control message
     *
     * @param item
     *            Playlist item
     */
    private void sendVODInitCM(IPlayItem item) {
        OOBControlMessage oobCtrlMsg = new OOBControlMessage();
        oobCtrlMsg.setTarget(IPassive.KEY);
        oobCtrlMsg.setServiceName("init");
        Map<String, Object> paramMap = new HashMap<String, Object>(1);
        paramMap.put("startTS", (int) item.getStart());
        oobCtrlMsg.setServiceParamMap(paramMap);
        msgInReference.get().sendOOBControlMessage(this, oobCtrlMsg);
    }

    /**
     * Send VOD seek control message
     *
     * @param msgIn
     *            Message input
     * @param position
     *            Playlist item
     * @return Out-of-band control message call result or -1 on failure
     */
    private int sendVODSeekCM(int position) {
        OOBControlMessage oobCtrlMsg = new OOBControlMessage();
        oobCtrlMsg.setTarget(ISeekableProvider.KEY);
        oobCtrlMsg.setServiceName("seek");
        Map<String, Object> paramMap = new HashMap<String, Object>(1);
        paramMap.put("position", position);
        oobCtrlMsg.setServiceParamMap(paramMap);
        msgInReference.get().sendOOBControlMessage(this, oobCtrlMsg);
        if (oobCtrlMsg.getResult() instanceof Integer) {
            return (Integer) oobCtrlMsg.getResult();
        } else {
            return -1;
        }
    }

    /**
     * Send VOD check video control message
     *
     * @return result of oob control message
     */
    private boolean sendCheckVideoCM() {
        OOBControlMessage oobCtrlMsg = new OOBControlMessage();
        oobCtrlMsg.setTarget(IStreamTypeAwareProvider.KEY);
        oobCtrlMsg.setServiceName("hasVideo");
        msgInReference.get().sendOOBControlMessage(this, oobCtrlMsg);
        if (oobCtrlMsg.getResult() instanceof Boolean) {
            return (Boolean) oobCtrlMsg.getResult();
        } else {
            return false;
        }
    }

    /** {@inheritDoc} */
    public void onOOBControlMessage(IMessageComponent source, IPipe pipe, OOBControlMessage oobCtrlMsg) {
        if ("ConnectionConsumer".equals(oobCtrlMsg.getTarget())) {
            if (source instanceof IProvider) {
                IMessageOutput out = msgOutReference.get();
                if (out != null) {
                    out.sendOOBControlMessage((IProvider) source, oobCtrlMsg);
                } else {
                    // this may occur when a client attempts to play and then disconnects
                    log.warn("Output is not available, message cannot be sent");
                    close();
                }
            }
        }
    }

    /** {@inheritDoc} */
    public void onPipeConnectionEvent(PipeConnectionEvent event) {
        switch (event.getType()) {
            case PROVIDER_CONNECT_PUSH:
                if (event.getProvider() != this) {
                    if (waitLiveJob != null) {
                        schedulingService.removeScheduledJob(waitLiveJob);
                        waitLiveJob = null;
                    }
                    sendPublishedStatus(currentItem.get());
                }
                break;
            case PROVIDER_DISCONNECT:
                if (pullMode) {
                    sendStopStatus(currentItem.get());
                } else {
                    sendUnpublishedStatus(currentItem.get());
                }
                break;
            case CONSUMER_CONNECT_PULL:
                if (event.getConsumer() == this) {
                    pullMode = true;
                }
                break;
            case CONSUMER_CONNECT_PUSH:
                if (event.getConsumer() == this) {
                    pullMode = false;
                }
                break;
            default:
                if (isDebug) {
                    log.debug("Unhandled pipe event: {}", event);
                }
        }
    }

    private boolean shouldLogPacketDrop() {
        long now = TimeUnit.NANOSECONDS.toMillis(System.nanoTime());
        if (now - droppedPacketsCountLastLogTimestamp > droppedPacketsCountLogInterval) {
            droppedPacketsCountLastLogTimestamp = now;
            return true;
        }

        return false;
    }

    /** {@inheritDoc} */
    public void pushMessage(IPipe pipe, IMessage message) throws IOException {
        if (!pullMode) {
            if (!configsDone) {
                log.debug("dump early");
                return;
            }
        }
        // Debug logging to trace source type
        if (message instanceof RTMPMessage rtmpMsg && rtmpMsg.getBody() != null) {
            byte srcType = rtmpMsg.getBody().getSourceType();
            if (srcType != Constants.SOURCE_TYPE_LIVE && rtmpMsg.getBody() instanceof VideoData) {
                log.warn("pushMessage: VideoData has source type {} (expected LIVE=1), class: {}", new Object[] { srcType, rtmpMsg.getBody().getClass().getName() });
            }
        }
        String sessionId = subscriberStream.getConnection().getSessionId();
        if (message instanceof RTMPMessage) {
            IMessageInput msgIn = msgInReference.get();
            RTMPMessage rtmpMessage = (RTMPMessage) message;
            IRTMPEvent body = rtmpMessage.getBody();
            if (body instanceof IStreamData) {
                final String subscribedStreamName = subscriberStream.getBroadcastStreamPublishName();
                // the subscriber paused
                if (subscriberStream.getState() == StreamState.PAUSED) {
                    if (log.isInfoEnabled() && shouldLogPacketDrop()) {
                        log.info("Dropping packet because we are paused. sessionId={} stream={} count={}", sessionId, subscribedStreamName, droppedPacketsCount);
                    }
                    videoFrameDropper.dropPacket(rtmpMessage);
                    return;
                }
                if (body instanceof VideoData && body.getSourceType() == Constants.SOURCE_TYPE_LIVE) {
                    if (log.isDebugEnabled()) {
                        VideoData vd = (VideoData) body;
                        log.debug("PlayEngine received video: ts={} frameType={} size={}", body.getTimestamp(), vd.getFrameType(), vd.getData() != null ? vd.getData().limit() : 0);
                    }
                    // We only want to drop packets from a live stream. VOD streams we let it buffer.
                    // We don't want a user watching a movie to see a choppy video due to low bandwidth.
                    if (msgIn instanceof IBroadcastScope) {
                        IBroadcastStream stream = (IBroadcastStream) ((IBroadcastScope) msgIn).getClientBroadcastStream();
                        if (stream != null && stream.getCodecInfo() != null) {
                            IVideoStreamCodec videoCodec = stream.getCodecInfo().getVideoCodec();
                            // Check if we were waiting for a keyframe and one is now available
                            // IMPORTANT: Only switch modes when the CURRENT frame is a keyframe,
                            // not just when one exists in the codec, to prevent sending interframes
                            // before the keyframe has been transmitted
                            if (videoCodec != null && waitingForKeyframe) {
                                VideoData videoData = (VideoData) body;
                                if (videoData.isKeyFrame()) {
                                    log.debug("Keyframe frame received, switching from SEND_KEYFRAMES_CHECK to SEND_INTERFRAMES mode");
                                    // Use SEND_INTERFRAMES to let the frame dropper state machine
                                    // naturally progress to SEND_ALL when conditions are right
                                    videoFrameDropper.reset(IFrameDropper.SEND_INTERFRAMES);
                                    waitingForKeyframe = false;
                                } else {
                                    log.trace("Still waiting for keyframe, current frame is {}", videoData.getFrameType());
                                }
                            }
                            // dont try to drop frames if video codec is null
                            if (videoCodec != null && videoCodec.canDropFrames()) {
                                if (!receiveVideo) {
                                    videoFrameDropper.dropPacket(rtmpMessage);
                                    droppedPacketsCount++;
                                    if (log.isInfoEnabled() && shouldLogPacketDrop()) {
                                        // client disabled video or the app doesn't have enough bandwidth allowed for this stream
                                        log.info("Drop packet. Failed to acquire token or no video. sessionId={} stream={} count={}", sessionId, subscribedStreamName, droppedPacketsCount);
                                    }
                                    return;
                                }
                                // Implement some sort of back-pressure on video streams. When the client is on a congested
                                // connection, Red5 cannot send packets fast enough. Mina puts these packets into an
                                // unbounded queue. If we generate video packets fast enough, the queue would get large
                                // which may trigger an OutOfMemory exception. To mitigate this, we check the size of
                                // pending video messages and drop video packets until the queue is below the threshold.
                                // only check for frame dropping if the codec supports it
                                long pendingVideos = pendingVideoMessages();
                                if (isTrace) {
                                    log.trace("Pending messages sessionId={} stream={} pending={} threshold={} sequential={} dropped={}", new Object[] { sessionId, subscribedStreamName, pendingVideos, maxPendingVideoFrames, numSequentialPendingVideoFrames, droppedPacketsCount });
                                }
                                if (!videoFrameDropper.canSendPacket(rtmpMessage, pendingVideos)) {
                                    // drop frame as it depends on other frames that were dropped before
                                    droppedPacketsCount++;
                                    if (log.isInfoEnabled() && shouldLogPacketDrop()) {
                                        log.info("Frame dropper says to drop packet. sessionId={} stream={} dropped={}", sessionId, subscribedStreamName, droppedPacketsCount);
                                    }
                                    return;
                                }
                                // Log that video will be sent
                                if (log.isDebugEnabled()) {
                                    VideoData vd = (VideoData) body;
                                    log.debug("Video passing to subscriber: ts={} frameType={} waitingForKeyframe={}", body.getTimestamp(), vd.getFrameType(), waitingForKeyframe);
                                }
                                // increment the number of times we had pending video frames sequentially
                                if (pendingVideos > 1) {
                                    numSequentialPendingVideoFrames++;
                                } else {
                                    // reset number of sequential pending frames if 1 or 0 are pending
                                    numSequentialPendingVideoFrames = 0;
                                }
                                if (pendingVideos > maxPendingVideoFrames || numSequentialPendingVideoFrames > maxSequentialPendingVideoFrames) {
                                    droppedPacketsCount++;
                                    if (log.isInfoEnabled() && shouldLogPacketDrop()) {
                                        log.info("Drop packet. Pending above threshold. sessionId={} stream={} pending={} threshold={} sequential={} dropped={}", new Object[] { sessionId, subscribedStreamName, pendingVideos, maxPendingVideoFrames, numSequentialPendingVideoFrames, droppedPacketsCount });
                                    }
                                    // drop because the client has insufficient bandwidth
                                    long now = System.currentTimeMillis();
                                    if (bufferCheckInterval > 0 && now >= nextCheckBufferUnderrun) {
                                        // notify client about frame dropping (keyframe)
                                        sendInsufficientBandwidthStatus(currentItem.get());
                                        nextCheckBufferUnderrun = now + bufferCheckInterval;
                                    }
                                    videoFrameDropper.dropPacket(rtmpMessage);
                                    return;
                                }
                                // we are ok to send, check if we should send buffered frame
                                if (bufferedInterframeIdx > -1) {
                                    IVideoStreamCodec.FrameData fd = videoCodec.getInterframe(bufferedInterframeIdx++);
                                    if (fd != null) {
                                        VideoData interframe = new VideoData(fd.getFrame());
                                        interframe.setTimestamp(body.getTimestamp());
                                        rtmpMessage = RTMPMessage.build(interframe);
                                    } else {
                                        // it means that new keyframe was received and we should send current frames instead of buffered
                                        bufferedInterframeIdx = -1;
                                    }
                                }
                            }
                        }
                    }
                } else if (body instanceof AudioData) {
                    if (log.isDebugEnabled()) {
                        log.debug("PlayEngine received audio: ts={}", body.getTimestamp());
                    }
                    if (!receiveAudio && sendBlankAudio) {
                        // send blank audio packet to reset player
                        sendBlankAudio = false;
                        body = new AudioData();
                        if (lastMessageTs > 0) {
                            body.setTimestamp(lastMessageTs);
                        } else {
                            body.setTimestamp(0);
                        }
                        rtmpMessage = RTMPMessage.build(body);
                    } else if (!receiveAudio) {
                        return;
                    }
                }
                sendMessage(rtmpMessage);
            } else {
                throw new RuntimeException(String.format("Expected IStreamData but got %s (type %s)", body.getClass(), body.getDataType()));
            }
        } else if (message instanceof ResetMessage) {
            sendReset();
        } else {
            msgOutReference.get().pushMessage(message);
        }
    }

    /**
     * Get number of pending video messages
     *
     * @return Number of pending video messages
     */
    private long pendingVideoMessages() {
        IMessageOutput out = msgOutReference.get();
        if (out != null) {
            OOBControlMessage pendingRequest = new OOBControlMessage();
            pendingRequest.setTarget("ConnectionConsumer");
            pendingRequest.setServiceName("pendingVideoCount");
            out.sendOOBControlMessage(this, pendingRequest);
            if (pendingRequest.getResult() != null) {
                return (Long) pendingRequest.getResult();
            }
        }
        return 0L;
    }

    /**
     * Get number of pending messages to be sent
     *
     * @return Number of pending messages
     */
    private long pendingMessages() {
        return subscriberStream.getConnection().getPendingMessages();
    }

    /**
     * <p>isPullMode.</p>
     *
     * @return a boolean
     */
    public boolean isPullMode() {
        return pullMode;
    }

    /**
     * <p>isPaused.</p>
     *
     * @return a boolean
     */
    public boolean isPaused() {
        return subscriberStream.isPaused();
    }

    /**
     * Returns the timestamp of the last message sent.
     *
     * @return last message timestamp
     */
    public int getLastMessageTimestamp() {
        return lastMessageTs;
    }

    /**
     * <p>Getter for the field <code>playbackStart</code>.</p>
     *
     * @return a long
     */
    public long getPlaybackStart() {
        return playbackStart;
    }

    /**
     * <p>sendBlankAudio.</p>
     *
     * @param sendBlankAudio a boolean
     */
    public void sendBlankAudio(boolean sendBlankAudio) {
        this.sendBlankAudio = sendBlankAudio;
    }

    /**
     * Returns true if the engine currently receives audio.
     *
     * @return receive audio
     */
    public boolean receiveAudio() {
        return receiveAudio;
    }

    /**
     * Returns true if the engine currently receives audio and sets the new value.
     *
     * @param receive
     *            new value
     * @return old value
     */
    public boolean receiveAudio(boolean receive) {
        boolean oldValue = receiveAudio;
        //set new value
        if (receiveAudio != receive) {
            receiveAudio = receive;
        }
        return oldValue;
    }

    /**
     * Returns true if the engine currently receives video.
     *
     * @return receive video
     */
    public boolean receiveVideo() {
        return receiveVideo;
    }

    /**
     * Returns true if the engine currently receives video and sets the new value.
     *
     * @param receive
     *            new value
     * @return old value
     */
    public boolean receiveVideo(boolean receive) {
        boolean oldValue = receiveVideo;
        //set new value
        if (receiveVideo != receive) {
            receiveVideo = receive;
        }
        return oldValue;
    }

    /**
     * Releases pending message body, nullifies pending message object
     */
    private void releasePendingMessage() {
        if (pendingMessage != null) {
            IRTMPEvent body = pendingMessage.getBody();
            if (body instanceof IStreamData && ((IStreamData<?>) body).getData() != null) {
                ((IStreamData<?>) body).getData().free();
            }
            pendingMessage = null;
        }
    }

    /**
     * Check if sending the given message was enabled by the client.
     *
     * @param message
     *            the message to check
     * @return true if the message should be sent, false otherwise (and the message is discarded)
     */
    protected boolean checkSendMessageEnabled(RTMPMessage message) {
        IRTMPEvent body = message.getBody();
        if (!receiveAudio && body instanceof AudioData) {
            // The user doesn't want to get audio packets
            ((IStreamData<?>) body).getData().free();
            if (sendBlankAudio) {
                // Send reset audio packet
                sendBlankAudio = false;
                body = new AudioData();
                // We need a zero timestamp
                if (lastMessageTs >= 0) {
                    body.setTimestamp(lastMessageTs - timestampOffset);
                } else {
                    body.setTimestamp(-timestampOffset);
                }
                message = RTMPMessage.build(body);
            } else {
                return false;
            }
        } else if (!receiveVideo && body instanceof VideoData) {
            // The user doesn't want to get video packets
            ((IStreamData<?>) body).getData().free();
            return false;
        }
        return true;
    }

    /**
     * Schedule a stop to be run from a separate thread to allow the background thread to stop cleanly.
     */
    private void runDeferredStop() {
        // Stop current jobs from running.
        clearWaitJobs();
        // Schedule deferred stop executor.
        log.trace("Ran deferred stop");
        if (deferredStop == null) {
            // set deferred stop if we get a job name returned
            deferredStop = subscriberStream.scheduleWithFixedDelay(new DeferredStopRunnable(), 100);
        }
    }

    private void cancelDeferredStop() {
        log.debug("Cancel deferred stop");
        if (deferredStop != null) {
            subscriberStream.cancelJob(deferredStop);
            deferredStop = null;
        }
    }

    /**
     * Runnable worker to handle seek operations.
     */
    private final class SeekRunnable implements Runnable {

        private final int position;

        SeekRunnable(int position) {
            this.position = position;
        }

        @SuppressWarnings("incomplete-switch")
        public void run() {
            log.trace("Seek: {}", position);
            boolean startPullPushThread = false;
            switch (subscriberStream.getState()) {
                case PLAYING:
                    startPullPushThread = true;
                case PAUSED:
                case STOPPED:
                    //allow seek if playing, paused, or stopped
                    if (!pullMode) {
                        // throw new OperationNotSupportedException();
                        throw new RuntimeException();
                    }
                    releasePendingMessage();
                    clearWaitJobs();
                    break;
                default:
                    throw new IllegalStateException("Cannot seek in current state");
            }
            sendClearPing();
            sendReset();
            sendSeekStatus(currentItem.get(), position);
            sendStartStatus(currentItem.get());
            int seekPos = sendVODSeekCM(position);
            // we seeked to the nearest keyframe so use real timestamp now
            if (seekPos == -1) {
                seekPos = position;
            }
            //what should our start be?
            log.trace("Current playback start: {}", playbackStart);
            playbackStart = System.currentTimeMillis() - seekPos;
            log.trace("Playback start: {} seek pos: {}", playbackStart, seekPos);
            subscriberStream.onChange(StreamState.SEEK, currentItem.get(), seekPos);
            // start off with not having sent any message
            boolean messageSent = false;
            // read our client state
            switch (subscriberStream.getState()) {
                case PAUSED:
                case STOPPED:
                    // we send a single snapshot on pause
                    if (sendCheckVideoCM()) {
                        IMessage msg = null;
                        IMessageInput in = msgInReference.get();
                        do {
                            try {
                                msg = in.pullMessage();
                            } catch (Throwable err) {
                                log.warn("Error while pulling message", err);
                                break;
                            }
                            if (msg instanceof RTMPMessage) {
                                RTMPMessage rtmpMessage = (RTMPMessage) msg;
                                IRTMPEvent body = rtmpMessage.getBody();
                                if (body instanceof VideoData && ((VideoData) body).getFrameType() == VideoFrameType.KEYFRAME) {
                                    //body.setTimestamp(seekPos);
                                    doPushMessage(rtmpMessage);
                                    rtmpMessage.getBody().release();
                                    messageSent = true;
                                    lastMessageTs = body.getTimestamp();
                                    break;
                                }
                            }
                        } while (msg != null);
                    }
            }
            // seeked past end of stream
            long length = currentItem.get().getLength();
            if (length >= 0 && (position - streamOffset) >= length) {
                stop();
            }
            // if no message has been sent by this point send an audio packet
            if (!messageSent) {
                // Send blank audio packet to notify client about new position
                log.debug("Sending blank audio packet");
                AudioData audio = new AudioData();
                audio.setTimestamp(seekPos);
                audio.setHeader(new Header());
                audio.getHeader().setTimer(seekPos);
                RTMPMessage audioMessage = RTMPMessage.build(audio);
                lastMessageTs = seekPos;
                doPushMessage(audioMessage);
                audioMessage.getBody().release();
            }
            if (!messageSent && subscriberStream.getState() == StreamState.PLAYING) {
                boolean isRTMPTPlayback = subscriberStream.getConnection().getProtocol().equals("rtmpt");
                // send all frames from last keyframe up to requested position and fill client buffer
                if (sendCheckVideoCM()) {
                    final long clientBuffer = subscriberStream.getClientBufferDuration();
                    IMessage msg = null;
                    IMessageInput in = msgInReference.get();
                    int msgSent = 0;
                    do {
                        try {
                            msg = in.pullMessage();
                            if (msg instanceof RTMPMessage) {
                                RTMPMessage rtmpMessage = (RTMPMessage) msg;
                                IRTMPEvent body = rtmpMessage.getBody();
                                if (body.getTimestamp() >= position + (clientBuffer * 2)) {
                                    // client buffer should be full by now, continue regular pull/push
                                    releasePendingMessage();
                                    if (checkSendMessageEnabled(rtmpMessage)) {
                                        pendingMessage = rtmpMessage;
                                    }
                                    break;
                                }
                                if (!checkSendMessageEnabled(rtmpMessage)) {
                                    continue;
                                }
                                msgSent++;
                                sendMessage(rtmpMessage);
                            }
                        } catch (Throwable err) {
                            log.warn("Error while pulling message", err);
                            break;
                        }
                    } while (!isRTMPTPlayback && (msg != null));
                    log.trace("msgSent: {}", msgSent);
                    playbackStart = System.currentTimeMillis() - lastMessageTs;
                }
            }
            // start pull-push
            if (startPullPushThread) {
                ensurePullAndPushRunning();
            }
        }
    }

    /**
     * Periodically triggered by executor to send messages to the client.
     */
    private final class PullAndPushRunnable implements IScheduledJob {

        /**
         * Trigger sending of messages.
         */
        public void execute(ISchedulingService svc) {
            // ensure the job is not already running
            if (pushPullRunning.compareAndSet(false, true)) {
                try {
                    // handle any pending operations
                    Runnable worker = null;
                    while (!pendingOperations.isEmpty()) {
                        log.debug("Pending operations: {}", pendingOperations.size());
                        // remove the first operation and execute it
                        worker = pendingOperations.remove();
                        log.debug("Worker: {}", worker);
                        // if the operation is seek, ensure it is the last request in the set
                        while (worker instanceof SeekRunnable) {
                            Runnable tmp = pendingOperations.peek();
                            if (tmp != null && tmp instanceof SeekRunnable) {
                                worker = pendingOperations.remove();
                            } else {
                                break;
                            }
                        }
                        if (worker != null) {
                            log.debug("Executing pending operation");
                            worker.run();
                        }
                    }
                    // receive then send if message is data (not audio or video)
                    if (subscriberStream.getState() == StreamState.PLAYING && pullMode) {
                        if (pendingMessage != null) {
                            IRTMPEvent body = pendingMessage.getBody();
                            if (okayToSendMessage(body)) {
                                sendMessage(pendingMessage);
                                releasePendingMessage();
                            } else {
                                return;
                            }
                        } else {
                            IMessage msg = null;
                            IMessageInput in = msgInReference.get();
                            do {
                                msg = in.pullMessage();
                                if (msg != null) {
                                    if (msg instanceof RTMPMessage) {
                                        RTMPMessage rtmpMessage = (RTMPMessage) msg;
                                        if (checkSendMessageEnabled(rtmpMessage)) {
                                            // Adjust timestamp when playing lists
                                            IRTMPEvent body = rtmpMessage.getBody();
                                            body.setTimestamp(body.getTimestamp() + timestampOffset);
                                            if (okayToSendMessage(body)) {
                                                log.trace("ts: {}", rtmpMessage.getBody().getTimestamp());
                                                sendMessage(rtmpMessage);
                                                IoBuffer data = ((IStreamData<?>) body).getData();
                                                if (data != null) {
                                                    data.free();
                                                }
                                                // continue to pull and feed
                                            } else {
                                                // ensure p/p executable scheduled and break to exit
                                                pendingMessage = rtmpMessage;
                                                ensurePullAndPushRunning();
                                                break;
                                            }
                                        }
                                    }
                                } else {
                                    // No more packets to send
                                    log.debug("Ran out of packets");
                                    runDeferredStop();
                                }
                            } while (msg != null);
                        }
                    }
                } catch (IOException err) {
                    // we couldn't get more data, stop stream.
                    log.warn("Error while getting message", err);
                    runDeferredStop();
                } finally {
                    // reset running flag
                    pushPullRunning.compareAndSet(true, false);
                }
            } else {
                log.debug("Push / pull already running");
            }
        }
    }

    private class DeferredStopRunnable implements IScheduledJob {

        public void execute(ISchedulingService service) {
            if (isClientBufferEmpty()) {
                log.trace("Buffer is empty, stop will proceed");
                stop();
            }
        }

    }

    /**
     * <p>Setter for the field <code>maxPendingVideoFrames</code>.</p>
     *
     * @param maxPendingVideoFrames
     *            the maxPendingVideoFrames to set
     */
    public void setMaxPendingVideoFrames(int maxPendingVideoFrames) {
        this.maxPendingVideoFrames = maxPendingVideoFrames;
    }

    /**
     * <p>Setter for the field <code>maxSequentialPendingVideoFrames</code>.</p>
     *
     * @param maxSequentialPendingVideoFrames
     *            the maxSequentialPendingVideoFrames to set
     */
    public void setMaxSequentialPendingVideoFrames(int maxSequentialPendingVideoFrames) {
        this.maxSequentialPendingVideoFrames = maxSequentialPendingVideoFrames;
    }

}
